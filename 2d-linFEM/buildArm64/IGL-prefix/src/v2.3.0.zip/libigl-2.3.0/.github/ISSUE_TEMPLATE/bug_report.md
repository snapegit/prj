---
name: 🐛 Bug Report
about: If something isn't working as expected
title: ''
labels: bug, pending verification
assignees: ''

---

#### Describe the bug
<!-- A clear and concise description of what the bug is. -->

#### Platform
<!-- Check all that apply (change to `[x]`) -->

- [ ] Windows
- [ ] macOS
- [ ] Linux
